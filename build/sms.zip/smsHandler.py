import boto3
sns = boto3.client('sns', region_name='ap-southeast-1')

def handler(event, context):
    sns.publish(
      PhoneNumber=event['phoneNumber'],   # ví dụ "+84123456789"
      Message=event['message']
    )
