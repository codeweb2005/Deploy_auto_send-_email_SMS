import json
import boto3

sf = boto3.client('stepfunctions')
STATE_MACHINE_ARN = 'arn:aws:states:…:stateMachine:YourStateMachine'

# Cấu hình CORS chung
CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',            # hoặc domain cụ thể của bạn
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'OPTIONS,POST'
}

def handler(event, context):
    # 1. Nếu là preflight request, trả về 200 ngay
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': ''
        }

    # 2. Xử lý POST bình thường
    body = json.loads(event.get('body') or '{}')
    resp = sf.start_execution(
        stateMachineArn=STATE_MACHINE_ARN,
        input=json.dumps(body)
    )
    return {
        'statusCode': 200,
        'headers': CORS_HEADERS,
        'body': json.dumps({'executionArn': resp['executionArn']})
    }
