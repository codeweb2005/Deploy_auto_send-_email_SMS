import os
import boto3

# Thay us-east-1 bằng region bạn đang dùng SES nếu khác
SES_REGION = os.environ.get('SES_REGION', 'ap-southeast-1')
# Email đã verify trong SES, phải là email bạn sở hữu
SOURCE_EMAIL = os.environ.get('SOURCE_EMAIL', 'you@yourdomain.com')

ses = boto3.client('ses', region_name=SES_REGION)

def handler(event, context):
    try:
        resp = ses.send_email(
            Source=SOURCE_EMAIL,                         # phải là email đã verify
            Destination={
                'ToAddresses': [ event['email'] ]       # bên nhận (nếu còn trong sandbox thì cũng phải verify)
            },
            Message={
                'Subject': {
                    'Data': event['subject'],
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': event['body'],
                        'Charset': 'UTF-8'
                    }
                }
            },
            # nếu muốn làm reply‐to khác biệt:
            # ReplyToAddresses=[ SOURCE_EMAIL ],
        )
        return {
            'statusCode': 200,
            'body': {'status': 'Email sent', 'messageId': resp['MessageId']}
        }

    except Exception as e:
        # log lỗi để debug
        print("SES send_email error:", e)
        return {
            'statusCode': 500,
            'body': {'status': 'failed', 'error': str(e)}
        }
